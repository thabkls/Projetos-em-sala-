import { useState } from 'react';
import { SearchHeader } from './components/SearchHeader';
import { HomePage } from './components/HomePage';
import { CollectionsPage } from './components/CollectionsPage';
import { MerchandisePage } from './components/MerchandisePage';
import { GamesPage } from './components/GamesPage';
import { EventsPage } from './components/EventsPage';
import { BottomNavigation } from './components/BottomNavigation';
import { CartPage } from './components/CartPage';
import { CheckoutPage } from './components/CheckoutPage';
import { PaymentStatusPage } from './components/PaymentStatusPage';
import { SkipLink } from './components/SkipLink';
import { toast } from 'sonner@2.0.3';
import backgroundImage from 'figma:asset/db168cab506ce95d8016da0fb4e795c4714eb1d8.png';
import dragonBookImage from 'figma:asset/8442087deef48f76643da4b5019e5c52ec110ff3.png';
import dragonReadingImage from 'figma:asset/aacf175f583e6596e90950db2cf4fbf11d158dc1.png';

// Mock data for fantasy-focused bookstore
const categories = [
  'Todos', 'Fantasia Épica', 'RPG & D&D', 'Urban Fantasy', 'Steampunk', 'Mitologia', 'Horror Cósmico', 'Sci-Fi'
];

const allBooks = [
  {
    id: '1',
    title: 'O Senhor dos Anéis: A Sociedade do Anel',
    author: 'J.R.R. Tolkien',
    price: 39.90,
    rating: 4.8,
    coverUrl: 'https://images.unsplash.com/photo-1640688738996-4f3db1b7ad58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwbWFnaWMlMjBib29rcyUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzU3OTgxNzE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '2',
    title: 'A Guerra dos Tronos',
    author: 'George R.R. Martin',
    price: 49.90,
    rating: 4.9,
    coverUrl: 'https://images.unsplash.com/photo-1677104165819-2e5ab9a0821f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYm9va3MlMjBkdW5nZW9ucyUyMGRyYWdvbnN8ZW58MXx8fHwxNzU3OTgxNzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '3',
    title: 'Player\'s Handbook D&D 5ª Edição',
    author: 'Wizards of the Coast',
    price: 179.90,
    rating: 4.8,
    coverUrl: 'https://images.unsplash.com/photo-1633081121114-f151f703832c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwdGFibGV0b3AlMjBtZWRpZXZhbHxlbnwxfHx8fDE3NTc5ODE3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '4',
    title: 'O Nome do Vento',
    author: 'Patrick Rothfuss',
    price: 42.90,
    rating: 4.7,
    coverUrl: 'https://images.unsplash.com/photo-1735720518793-804614ff5c48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwY29sbGVjdGlibGVzJTIwbWVyY2hhbmRpc2V8ZW58MXx8fHwxNzU3OTgxNzI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '5',
    title: 'A Roda do Tempo: O Olho do Mundo',
    author: 'Robert Jordan',
    price: 45.90,
    rating: 4.6,
    coverUrl: 'https://images.unsplash.com/photo-1640688738996-4f3db1b7ad58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwbWFnaWMlMjBib29rcyUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzU3OTgxNzE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '6',
    title: 'O Hobbit',
    author: 'J.R.R. Tolkien',
    price: 35.90,
    rating: 4.8,
    coverUrl: 'https://images.unsplash.com/photo-1677104165819-2e5ab9a0821f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYm9va3MlMjBkdW5nZW9ucyUyMGRyYWdvbnN8ZW58MXx8fHwxNzU3OTgxNzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '7',
    title: 'As Crônicas de Nárnia',
    author: 'C.S. Lewis',
    price: 39.90,
    rating: 4.7,
    coverUrl: 'https://images.unsplash.com/photo-1633081121114-f151f703832c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwdGFibGV0b3AlMjBtZWRpZXZhbHxlbnwxfHx8fDE3NTc5ODE3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: '8',
    title: 'Duna',
    author: 'Frank Herbert',
    price: 44.90,
    rating: 4.5,
    coverUrl: 'https://images.unsplash.com/photo-1735720518793-804614ff5c48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwY29sbGVjdGlibGVzJTIwbWVyY2hhbmRpc2V8ZW58MXx8fHwxNzU3OTgxNzI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

interface CartItem {
  id: string;
  title: string;
  author: string;
  price: number;
  coverUrl: string;
  quantity: number;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean | null>(null);

  const addToCart = (bookId: string) => {
    const book = allBooks.find(b => b.id === bookId);
    if (!book) return;

    setCartItems(prev => {
      const existingItem = prev.find(item => item.id === bookId);
      if (existingItem) {
        toast.success(`Quantidade de "${book.title}" atualizada no carrinho`);
        return prev.map(item =>
          item.id === bookId 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        toast.success(`"${book.title}" adicionado ao carrinho`);
        return [...prev, {
          id: book.id,
          title: book.title,
          author: book.author,
          price: book.price,
          coverUrl: book.coverUrl,
          quantity: 1
        }];
      }
    });
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity === 0) {
      removeFromCart(itemId);
      return;
    }
    
    setCartItems(prev =>
      prev.map(item =>
        item.id === itemId ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (itemId: string) => {
    const item = cartItems.find(i => i.id === itemId);
    if (item) {
      toast.success(`"${item.title}" removido do carrinho`);
    }
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const handleNavigation = (page: string) => {
    setCurrentPage(page);
  };

  const handleCheckout = () => {
    setCurrentPage('checkout');
  };

  const handlePaymentComplete = (success: boolean) => {
    setPaymentSuccess(success);
    setCurrentPage('payment-result');
    
    if (success) {
      setCartItems([]); // Clear cart on successful payment
    }
  };

  const handleBackToHome = () => {
    setCurrentPage('home');
    setPaymentSuccess(null);
  };

  const handleTryAgain = () => {
    setCurrentPage('checkout');
    setPaymentSuccess(null);
  };

  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const featuredBooks = allBooks.slice(0, 3);
  const popularBooks = allBooks.slice(3, 8);

  // Render current page
  if (currentPage === 'cart') {
    return (
      <CartPage
        items={cartItems}
        onBack={() => setCurrentPage('home')}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={handleCheckout}
      />
    );
  }

  if (currentPage === 'checkout') {
    return (
      <CheckoutPage
        total={cartTotal}
        onBack={() => setCurrentPage('cart')}
        onPaymentComplete={handlePaymentComplete}
      />
    );
  }

  if (currentPage === 'payment-result' && paymentSuccess !== null) {
    return (
      <PaymentStatusPage
        success={paymentSuccess}
        onBackToHome={handleBackToHome}
        onTryAgain={handleTryAgain}
      />
    );
  }

  // Home page and other pages
  return (
    <div 
      className="min-h-screen bg-background text-foreground dark relative"
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        backgroundAttachment: 'fixed'
      }}
    >
      {/* Background overlay for better readability */}
      <div className="absolute inset-0 bg-background/85 dark:bg-background/90 z-0" />
      
      <div className="relative z-10">
        <SkipLink href="#main-content">
          Pular para o conteúdo principal
        </SkipLink>
      
      <SearchHeader 
        cartCount={cartCount}
        onCartClick={() => setCurrentPage('cart')}
        onMenuClick={() => {/* Menu functionality */}}
      />
      
      <main id="main-content">
        {currentPage === 'home' && (
          <HomePage
            categories={categories}
            selectedCategory={selectedCategory}
            onCategorySelect={setSelectedCategory}
            featuredBooks={featuredBooks}
            popularBooks={popularBooks}
            onAddToCart={addToCart}
            onNavigate={handleNavigation}
          />
        )}

        {currentPage === 'collections' && (
          <CollectionsPage
            onBack={() => setCurrentPage('home')}
            onAddToCart={addToCart}
          />
        )}

        {currentPage === 'merchandise' && (
          <MerchandisePage
            onBack={() => setCurrentPage('home')}
            onAddToCart={addToCart}
          />
        )}

        {currentPage === 'games' && (
          <GamesPage
            onBack={() => setCurrentPage('home')}
            onAddToCart={addToCart}
          />
        )}

        {currentPage === 'events' && (
          <EventsPage
            onBack={() => setCurrentPage('home')}
          />
        )}
      </main>

        <BottomNavigation 
          currentPage={currentPage}
          onNavigate={handleNavigation}
        />
      </div>
    </div>
  );
}