import { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

interface CheckoutPageProps {
  total: number;
  onBack: () => void;
  onPaymentComplete: (success: boolean) => void;
}

export function CheckoutPage({ total, onBack, onPaymentComplete }: CheckoutPageProps) {
  const [paymentMethod, setPaymentMethod] = useState('credit');
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    pixKey: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Simulate random success/failure for demo
    const success = Math.random() > 0.3; // 70% success rate
    
    setIsProcessing(false);
    onPaymentComplete(success);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-background/95 dark:bg-background/98">
      <header className="bg-card border-b border-border px-4 py-3 safe-area-inset-top">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            aria-label="Voltar ao carrinho"
            disabled={isProcessing}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Finalizar Compra</h1>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Customer Information */}
          <Card className="p-4">
            <h2 className="font-semibold mb-4">Informações do Cliente</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">E-mail *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="seu@email.com"
                  required
                  disabled={isProcessing}
                  aria-describedby="email-help"
                />
                <p id="email-help" className="text-sm text-muted-foreground mt-1">
                  Enviaremos a confirmação para este e-mail
                </p>
              </div>
              <div>
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Seu nome completo"
                  required
                  disabled={isProcessing}
                />
              </div>
            </div>
          </Card>

          {/* Payment Method */}
          <Card className="p-4">
            <h2 className="font-semibold mb-4">Forma de Pagamento</h2>
            <RadioGroup 
              value={paymentMethod} 
              onValueChange={setPaymentMethod}
              className="space-y-3"
              disabled={isProcessing}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="credit" id="credit" />
                <Label htmlFor="credit" className="flex items-center gap-2 cursor-pointer">
                  <CreditCard className="w-4 h-4" />
                  Cartão de Crédito
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="pix" id="pix" />
                <Label htmlFor="pix" className="flex items-center gap-2 cursor-pointer">
                  <Smartphone className="w-4 h-4" />
                  PIX
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="boleto" id="boleto" />
                <Label htmlFor="boleto" className="flex items-center gap-2 cursor-pointer">
                  <DollarSign className="w-4 h-4" />
                  Boleto Bancário
                </Label>
              </div>
            </RadioGroup>
          </Card>

          {/* Credit Card Form */}
          {paymentMethod === 'credit' && (
            <Card className="p-4">
              <h3 className="font-semibold mb-4">Dados do Cartão</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="cardNumber">Número do Cartão *</Label>
                  <Input
                    id="cardNumber"
                    value={formData.cardNumber}
                    onChange={(e) => handleInputChange('cardNumber', e.target.value)}
                    placeholder="0000 0000 0000 0000"
                    required={paymentMethod === 'credit'}
                    disabled={isProcessing}
                    maxLength={19}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiryDate">Validade *</Label>
                    <Input
                      id="expiryDate"
                      value={formData.expiryDate}
                      onChange={(e) => handleInputChange('expiryDate', e.target.value)}
                      placeholder="MM/AA"
                      required={paymentMethod === 'credit'}
                      disabled={isProcessing}
                      maxLength={5}
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvv">CVV *</Label>
                    <Input
                      id="cvv"
                      value={formData.cvv}
                      onChange={(e) => handleInputChange('cvv', e.target.value)}
                      placeholder="123"
                      required={paymentMethod === 'credit'}
                      disabled={isProcessing}
                      maxLength={4}
                    />
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* PIX Form */}
          {paymentMethod === 'pix' && (
            <Card className="p-4">
              <h3 className="font-semibold mb-4">PIX</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Após confirmar, você receberá o código PIX para pagamento.
              </p>
            </Card>
          )}

          {/* Boleto Form */}
          {paymentMethod === 'boleto' && (
            <Card className="p-4">
              <h3 className="font-semibold mb-4">Boleto Bancário</h3>
              <p className="text-sm text-muted-foreground mb-4">
                O boleto será enviado por e-mail e tem vencimento em 3 dias úteis.
              </p>
            </Card>
          )}

          {/* Order Summary */}
          <Card className="p-4">
            <h3 className="font-semibold mb-4">Resumo do Pedido</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>R$ {total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Frete:</span>
                <span className="text-green-600">Grátis</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-semibold text-lg">
                <span>Total:</span>
                <span>R$ {total.toFixed(2)}</span>
              </div>
            </div>
          </Card>

          <Button 
            type="submit"
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            size="lg"
            disabled={isProcessing}
          >
            {isProcessing ? 'Processando...' : `Pagar R$ ${total.toFixed(2)}`}
          </Button>
        </form>
      </main>
    </div>
  );
}