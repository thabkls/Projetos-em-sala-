import { Button } from './ui/button';

interface CategoryChipProps {
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}

export function CategoryChip({ label, isActive = false, onClick }: CategoryChipProps) {
  return (
    <Button
      variant={isActive ? "default" : "outline"}
      size="sm"
      onClick={onClick}
      className={`rounded-full whitespace-nowrap focus:ring-2 focus:ring-ring focus:ring-offset-2 ${
        isActive 
          ? "bg-primary text-primary-foreground" 
          : "bg-secondary border-border text-secondary-foreground hover:bg-secondary/80"
      }`}
      aria-pressed={isActive}
      role="tab"
      aria-label={`Filtrar por categoria: ${label}`}
    >
      {label}
    </Button>
  );
}