import { ArrowLeft, Dice6, Users, Clock, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface BoardGame {
  id: string;
  name: string;
  price: number;
  rating: number;
  imageUrl: string;
  players: string;
  duration: string;
  age: string;
  category: string;
  isNew: boolean;
  inStock: boolean;
  description: string;
}

interface GamesPageProps {
  onBack: () => void;
  onAddToCart: (id: string) => void;
}

const boardGames: BoardGame[] = [
  {
    id: 'game1',
    name: 'Dungeons & Dragons - Kit Iniciante',
    price: 149.90,
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1633081121114-f151f703832c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwdGFibGV0b3AlMjBtZWRpZXZhbHxlbnwxfHx8fDE3NTc5ODE3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    players: '3-6',
    duration: '2-4h',
    age: '12+',
    category: 'RPG',
    isNew: true,
    inStock: true,
    description: 'Tudo que você precisa para começar sua aventura no mundo do RPG mais famoso do mundo.'
  },
  {
    id: 'game2',
    name: 'Gloomhaven',
    price: 599.90,
    rating: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1677104165819-2e5ab9a0821f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYm9va3MlMjBkdW5nZW9ucyUyMGRyYWdvbnN8ZW58MXx8fHwxNzU3OTgxNzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    players: '1-4',
    duration: '1-2h',
    age: '14+',
    category: 'Estratégia',
    isNew: false,
    inStock: true,
    description: 'RPG tático em um mundo de fantasia sombria com campanha épica.'
  },
  {
    id: 'game3',
    name: 'Mage Knight',
    price: 389.90,
    rating: 4.7,
    imageUrl: 'https://images.unsplash.com/photo-1735720518793-804614ff5c48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwY29sbGVjdGlibGVzJTIwbWVyY2hhbmRpc2V8ZW58MXx8fHwxNzU3OTgxNzI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    players: '1-4',
    duration: '2-4h',
    age: '14+',
    category: 'Aventura',
    isNew: false,
    inStock: false,
    description: 'Aventura épica de construção de deck em mundo fantástico.'
  },
  {
    id: 'game4',
    name: 'HeroQuest',
    price: 219.90,
    rating: 4.6,
    imageUrl: 'https://images.unsplash.com/photo-1640688738996-4f3db1b7ad58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwbWFnaWMlMjBib29rcyUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzU3OTgxNzE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    players: '2-5',
    duration: '1-2h',
    age: '14+',
    category: 'Aventura',
    isNew: true,
    inStock: true,
    description: 'O clássico jogo de exploração de masmorras retorna em nova edição.'
  }
];

const categories = ['Todos', 'RPG', 'Estratégia', 'Aventura', 'Card Games', 'Cooperativo'];

export function GamesPage({ onBack, onAddToCart }: GamesPageProps) {
  return (
    <div className="min-h-screen bg-background/95 dark:bg-background/98">
      <header className="bg-card border-b border-border px-4 py-3 safe-area-inset-top">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            aria-label="Voltar à página anterior"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Jogos de Tabuleiro</h1>
            <p className="text-sm text-muted-foreground">Aventuras épicas à sua mesa</p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        {/* Hero Section */}
        <Card className="p-6 mb-6 bg-gradient-to-r from-red-900/20 to-orange-900/20 border-red-700/30">
          <div className="flex items-center gap-2 mb-2">
            <Dice6 className="w-5 h-5 text-red-500" />
            <h2 className="font-semibold">Mesa de Aventuras</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Desde D&D até jogos de estratégia épicos. Sua próxima aventura começa aqui.
          </p>
          <div className="flex gap-2">
            <Badge variant="secondary" className="bg-red-500/10 text-red-600 border-red-500/20">
              <Users className="w-3 h-3 mr-1" />
              Jogos para grupos
            </Badge>
            <Badge variant="secondary" className="bg-orange-500/10 text-orange-600 border-orange-500/20">
              <Clock className="w-3 h-3 mr-1" />
              Sessões épicas
            </Badge>
          </div>
        </Card>

        {/* Categories */}
        <section className="mb-6">
          <h2 className="mb-3">Categorias</h2>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant="outline"
                size="sm"
                className="whitespace-nowrap rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </section>

        {/* D&D Spotlight */}
        <section className="mb-8">
          <h2 className="mb-4 flex items-center gap-2">
            <Dice6 className="w-5 h-5 text-purple-500" />
            Dungeons & Dragons
          </h2>
          <Card className="p-4 bg-gradient-to-r from-purple-900/10 to-indigo-900/10 border-purple-700/30">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium mb-1">Mesa de D&D toda Sexta-feira</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Junte-se à nossa mesa semanal na loja física
                </p>
                <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/40">
                  19h30 • Vagas limitadas
                </Badge>
              </div>
              <Button className="bg-purple-600 hover:bg-purple-700">
                Reservar Mesa
              </Button>
            </div>
          </Card>
        </section>

        {/* Featured Games */}
        <section className="mb-8">
          <h2 className="mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            Jogos em Destaque
          </h2>
          <div className="grid grid-cols-1 gap-4">
            {boardGames.map((game) => (
              <Card key={game.id} className="p-4 hover:shadow-lg transition-shadow">
                <div className="flex gap-4">
                  <div className="w-24 h-24 flex-shrink-0 relative">
                    <ImageWithFallback
                      src={game.imageUrl}
                      alt={game.name}
                      className="w-full h-full object-cover rounded"
                    />
                    {game.isNew && (
                      <Badge className="absolute -top-2 -right-2 bg-green-600 text-white text-xs px-1 py-0.5">
                        Novo
                      </Badge>
                    )}
                    {!game.inStock && (
                      <div className="absolute inset-0 bg-black/50 rounded flex items-center justify-center">
                        <span className="text-white text-xs font-medium">Esgotado</span>
                      </div>
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-medium line-clamp-1 mb-1">{game.name}</h3>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mb-1">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {game.players} jogadores
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {game.duration}
                          </span>
                          <span>{game.age}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {game.category}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                        <span className="text-sm">{game.rating}</span>
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {game.description}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-lg">R$ {game.price.toFixed(2)}</span>
                      <Button 
                        size="sm"
                        onClick={() => onAddToCart(game.id)}
                        disabled={!game.inStock}
                        className="bg-red-600 hover:bg-red-700 disabled:opacity-50"
                      >
                        {game.inStock ? 'Adicionar' : 'Esgotado'}
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Melancholic Gaming Atmosphere */}
        <Card className="mt-8 p-6 bg-gradient-to-r from-slate-900/50 to-indigo-900/40 border-slate-700/50">
          <div className="text-center">
            <h3 className="font-semibold mb-3 text-slate-200">Ecos de Aventuras Passadas</h3>
            <p className="text-sm text-slate-300/90 mb-4 italic leading-relaxed">
              "Na penumbra da taverna, entre dados rolados e mapas desdobrados, 
              encontramos não apenas diversão, mas a magia de criarmos histórias 
              que ecoarão em nossas memórias muito depois que a última vela se apagar."
            </p>
            <div className="flex justify-center gap-2 mb-4">
              <Badge variant="secondary" className="bg-slate-500/20 text-slate-300 border-slate-500/40">
                🎲 Memórias Épicas
              </Badge>
              <Badge variant="secondary" className="bg-indigo-500/20 text-indigo-300 border-indigo-500/40">
                ⚔️ Lendas Compartilhadas
              </Badge>
            </div>
          </div>
        </Card>

        {/* Gaming Community CTA */}
        <Card className="mt-6 p-6 bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border-blue-700/40">
          <div className="text-center">
            <Dice6 className="w-8 h-8 text-cyan-500 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Comunidade de Jogadores</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Participe do nosso grupo no Discord e encontre outros aventureiros para suas campanhas.
            </p>
            <Button className="bg-cyan-600 hover:bg-cyan-700">
              Entrar na Comunidade
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}