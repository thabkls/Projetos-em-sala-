import { CategoryChip } from './CategoryChip';
import { BookCard } from './BookCard';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Sparkles, Crown, Calendar, Dice6, Gift, BookOpen, Star, Flame } from 'lucide-react';
import { MelancholicSection } from './MelancholicSection';
import dragonBookImage from 'figma:asset/8442087deef48f76643da4b5019e5c52ec110ff3.png';
import dragonReadingImage from 'figma:asset/aacf175f583e6596e90950db2cf4fbf11d158dc1.png';

interface HomePageProps {
  categories: string[];
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
  featuredBooks: any[];
  popularBooks: any[];
  onAddToCart: (id: string) => void;
  onNavigate: (page: string) => void;
}

export function HomePage({ 
  categories, 
  selectedCategory, 
  onCategorySelect, 
  featuredBooks, 
  popularBooks, 
  onAddToCart,
  onNavigate 
}: HomePageProps) {
  return (
    <ScrollArea className="flex-1 pb-20">
      {/* Welcome Hero */}
      <section className="px-4 py-6">
        <Card className="p-6 bg-gradient-to-br from-purple-900/30 via-blue-900/20 to-indigo-900/30 border-purple-700/40 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-6 h-6 text-yellow-500" />
              <h2 className="text-xl font-semibold">Bem-vindo à Livraria Drachen</h2>
            </div>
            <p className="text-muted-foreground mb-4">
              Onde a magia dos livros encontra a aventura dos jogos. Descubra mundos fantásticos e viva aventuras épicas.
            </p>
            <div className="flex gap-2 flex-wrap">
              <Button 
                size="sm" 
                className="bg-purple-600 hover:bg-purple-700"
                onClick={() => onNavigate('collections')}
              >
                <Crown className="w-4 h-4 mr-2" />
                Edições Especiais
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => onNavigate('events')}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Próximos Eventos
              </Button>
            </div>
          </div>
          <div className="absolute top-0 right-0 opacity-10">
            <Sparkles className="w-32 h-32" />
          </div>
        </Card>
      </section>

      {/* Quick Actions */}
      <section className="px-4 pb-6">
        <div className="grid grid-cols-2 gap-3">
          <Card 
            className="p-4 cursor-pointer hover:shadow-lg transition-shadow bg-gradient-to-br from-emerald-900/20 to-green-900/20 border-emerald-700/30"
            onClick={() => onNavigate('games')}
          >
            <Dice6 className="w-6 h-6 text-emerald-500 mb-2" />
            <h3 className="font-medium text-sm mb-1">Jogos D&D</h3>
            <p className="text-xs text-muted-foreground">Mesa toda sexta</p>
          </Card>
          
          <Card 
            className="p-4 cursor-pointer hover:shadow-lg transition-shadow bg-gradient-to-br from-pink-900/20 to-rose-900/20 border-pink-700/30"
            onClick={() => onNavigate('merchandise')}
          >
            <Gift className="w-6 h-6 text-pink-500 mb-2" />
            <h3 className="font-medium text-sm mb-1">Mimos</h3>
            <p className="text-xs text-muted-foreground">Dados, mapas e mais</p>
          </Card>
        </div>
      </section>

      {/* Special Offers */}
      <section className="px-4 pb-6">
        <h2 className="mb-4 flex items-center gap-2">
          <Flame className="w-5 h-5 text-orange-500" />
          Ofertas Especiais
        </h2>
        <Card className="p-4 bg-gradient-to-r from-orange-900/20 to-red-900/20 border-orange-700/30">
          <div className="flex items-center justify-between">
            <div>
              <Badge className="bg-red-600 text-white mb-2">50% OFF</Badge>
              <h3 className="font-medium mb-1">Box Senhor dos Anéis Completo</h3>
              <p className="text-sm text-muted-foreground">De R$ 299,90 por apenas R$ 149,90</p>
            </div>
            <Button size="sm" className="bg-red-600 hover:bg-red-700">
              Ver Oferta
            </Button>
          </div>
        </Card>
      </section>

      {/* Pre-orders */}
      <section className="px-4 pb-6">
        <h2 className="mb-4 flex items-center gap-2">
          <Star className="w-5 h-5 text-yellow-500" />
          Pré-Vendas Exclusivas
        </h2>
        <div className="space-y-3">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium mb-1">The Winds of Winter</h3>
                <p className="text-sm text-muted-foreground mb-2">George R.R. Martin • Lançamento: 2025</p>
                <Badge variant="outline" className="text-xs">
                  Edição Limitada
                </Badge>
              </div>
              <div className="text-right">
                <p className="font-semibold">R$ 89,90</p>
                <Button size="sm" variant="outline" className="mt-1">
                  Reservar
                </Button>
              </div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium mb-1">D&D Player's Handbook 2024</h3>
                <p className="text-sm text-muted-foreground mb-2">Wizards of the Coast • Março 2025</p>
                <Badge variant="outline" className="text-xs">
                  Nova Edição
                </Badge>
              </div>
              <div className="text-right">
                <p className="font-semibold">R$ 179,90</p>
                <Button size="sm" variant="outline" className="mt-1">
                  Reservar
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Categories */}
      <section className="px-4 py-4" aria-labelledby="categories-heading">
        <h2 id="categories-heading" className="mb-3 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-blue-500" />
          Categorias
        </h2>
        <div 
          className="flex gap-2 overflow-x-auto pb-2"
          role="tablist"
          aria-label="Filtros de categoria"
        >
          {categories.map((category) => (
            <CategoryChip
              key={category}
              label={category}
              isActive={selectedCategory === category}
              onClick={() => onCategorySelect(category)}
            />
          ))}
        </div>
      </section>

      {/* Featured Books */}
      <section className="px-4 pb-6" aria-labelledby="featured-heading">
        <h2 id="featured-heading" className="mb-4">Livros em Destaque</h2>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {featuredBooks.map((book) => (
            <div key={book.id} className="w-36 flex-shrink-0">
              <BookCard {...book} price={`R$ ${book.price.toFixed(2)}`} onAddToCart={onAddToCart} />
            </div>
          ))}
        </div>
      </section>

      {/* Popular Books */}
      <section className="px-4 pb-6" aria-labelledby="popular-heading">
        <h2 id="popular-heading" className="mb-4">Mais Populares</h2>
        <div className="space-y-3">
          {popularBooks.map((book) => (
            <BookCard 
              key={book.id} 
              {...book} 
              price={`R$ ${book.price.toFixed(2)}`} 
              isHorizontal 
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>

      {/* Dragon's Wisdom Section */}
      <section className="px-4 pb-6">
        <h2 className="mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          A Sabedoria do Dragão
        </h2>
        <Card className="relative overflow-hidden border-amber-700/30 bg-gradient-to-r from-amber-900/30 via-orange-900/20 to-red-900/30">
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `url(${dragonReadingImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
          <div className="relative z-10 p-6">
            <h3 className="font-medium mb-3 text-amber-200">Lendas Sussurradas pelo Tempo</h3>
            <p className="text-sm text-amber-100/80 mb-4 leading-relaxed">
              "Nos tempos antigos, dragões eram os guardiões do conhecimento. 
              Dizem que cada livro lido com paixão desperta uma chama eterna na alma, 
              e aqueles que verdadeiramente amam as histórias carregam um pouco dessa magia ancestral."
            </p>
            <Badge variant="secondary" className="bg-amber-500/20 text-amber-300 border-amber-500/40">
              🐉 Sussurro Ancestral
            </Badge>
          </div>
        </Card>
      </section>

      {/* Melancholic Corner */}
      <section className="px-4 pb-6">
        <h2 className="mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-slate-400" />
          Cantinho da Melancolia
        </h2>
        <Card className="relative overflow-hidden border-slate-700/40 bg-gradient-to-br from-slate-900/40 via-gray-900/30 to-indigo-900/20">
          <div 
            className="absolute inset-0 opacity-15"
            style={{
              backgroundImage: `url(${dragonBookImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
          <div className="relative z-10 p-6">
            <h3 className="font-medium mb-3 text-slate-200">Reflexões à Luz de Velas</h3>
            <p className="text-sm text-slate-300/90 mb-4 leading-relaxed italic">
              "Há uma beleza silenciosa na solidão compartilhada com um bom livro. 
              Nas páginas amareladas pelo tempo, encontramos ecos de almas que, 
              como nós, buscaram refúgio nas palavras quando o mundo se tornava pesado demais."
            </p>
            <div className="flex gap-2">
              <Badge variant="secondary" className="bg-slate-500/20 text-slate-300 border-slate-500/40">
                📚 Nostalgia Literária
              </Badge>
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/40">
                🕯️ Atmosfera Intimista
              </Badge>
            </div>
          </div>
        </Card>
      </section>

      {/* Melancholic Section */}
      <MelancholicSection onNavigate={onNavigate} />

      {/* Newsletter */}
      <section className="px-4 pb-6">
        <Card className="p-6 bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border-blue-700/40">
          <div className="text-center">
            <h3 className="font-semibold mb-2">Pergaminho Drachen</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Receba novidades, ofertas exclusivas e convites para eventos especiais.
            </p>
            <Button className="bg-blue-600 hover:bg-blue-700">
              Inscrever-se
            </Button>
          </div>
        </Card>
      </section>
    </ScrollArea>
  );
}