import { ArrowLeft, Star, Crown, Sparkles } from 'lucide-react';
import dragonReadingImage from 'figma:asset/aacf175f583e6596e90950db2cf4fbf11d158dc1.png';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Collection {
  id: string;
  title: string;
  author: string;
  price: number;
  originalPrice?: number;
  rating: number;
  coverUrl: string;
  edition: string;
  isLimited: boolean;
  stock: number;
}

interface CollectionsPageProps {
  onBack: () => void;
  onAddToCart: (id: string) => void;
}

const collectibleBooks: Collection[] = [
  {
    id: 'col1',
    title: 'O Senhor dos Anéis - Edição Deluxe',
    author: 'J.R.R. Tolkien',
    price: 299.90,
    originalPrice: 399.90,
    rating: 4.9,
    coverUrl: 'https://images.unsplash.com/photo-1640688738996-4f3db1b7ad58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwbWFnaWMlMjBib29rcyUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzU3OTgxNzE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    edition: 'Edição de Colecionador',
    isLimited: true,
    stock: 5
  },
  {
    id: 'col2',
    title: 'As Crônicas de Nárnia - Box Completo',
    author: 'C.S. Lewis',
    price: 189.90,
    rating: 4.8,
    coverUrl: 'https://images.unsplash.com/photo-1677104165819-2e5ab9a0821f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYm9va3MlMjBkdW5nZW9ucyUyMGRyYWdvbnN8ZW58MXx8fHwxNzU3OTgxNzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    edition: 'Edição Especial',
    isLimited: false,
    stock: 12
  },
  {
    id: 'col3',
    title: 'Dungeons & Dragons - Manual do Mestre',
    author: 'Wizards of the Coast',
    price: 159.90,
    rating: 4.7,
    coverUrl: 'https://images.unsplash.com/photo-1633081121114-f151f703832c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwdGFibGV0b3AlMjBtZWRpZXZhbHxlbnwxfHx8fDE3NTc5ODE3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    edition: '5ª Edição',
    isLimited: false,
    stock: 8
  }
];

export function CollectionsPage({ onBack, onAddToCart }: CollectionsPageProps) {
  return (
    <div className="min-h-screen bg-background/95 dark:bg-background/98">
      <header className="bg-card border-b border-border px-4 py-3 safe-area-inset-top">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            aria-label="Voltar à página anterior"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Coleções & Edições Especiais</h1>
            <p className="text-sm text-muted-foreground">Livros raros e edições de colecionador</p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        {/* Hero Section */}
        <Card className="p-6 mb-6 bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-700/30">
          <div className="flex items-center gap-2 mb-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            <h2 className="font-semibold">Tesouro do Colecionador</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Edições limitadas, capas especiais e livros únicos para verdadeiros apreciadores da fantasia.
          </p>
          <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
            <Sparkles className="w-3 h-3 mr-1" />
            Apenas para membros do clube
          </Badge>
        </Card>

        {/* Pre-Orders Section */}
        <section className="mb-8">
          <h2 className="mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            Pré-Vendas Exclusivas
          </h2>
          <Card className="p-4 bg-gradient-to-r from-green-900/10 to-emerald-900/10 border-green-700/30">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium mb-1">A Casa do Dragão - Edição Limitada</h3>
                <p className="text-sm text-muted-foreground mb-2">George R.R. Martin</p>
                <Badge className="bg-green-600/20 text-green-400 border-green-600/40">
                  Pré-venda • Lançamento: Março 2025
                </Badge>
              </div>
              <div className="text-right">
                <p className="font-semibold text-lg">R$ 79,90</p>
                <Button size="sm" className="mt-2">
                  Reservar
                </Button>
              </div>
            </div>
          </Card>
        </section>

        {/* Collections Grid */}
        <section>
          <h2 className="mb-4 flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            Edições de Colecionador
          </h2>
          <div className="space-y-4">
            {collectibleBooks.map((book) => (
              <Card key={book.id} className="p-4 hover:shadow-lg transition-shadow">
                <div className="flex gap-4">
                  <div className="w-20 h-28 flex-shrink-0 relative">
                    <ImageWithFallback
                      src={book.coverUrl}
                      alt={`Capa de ${book.title}`}
                      className="w-full h-full object-cover rounded border-2 border-yellow-500/20"
                    />
                    {book.isLimited && (
                      <Badge className="absolute -top-2 -right-2 bg-red-600 text-white text-xs px-1 py-0.5">
                        Limitado
                      </Badge>
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-medium line-clamp-1 mb-1">{book.title}</h3>
                        <p className="text-sm text-muted-foreground">por {book.author}</p>
                      </div>
                      <div className="flex items-center gap-1" role="img" aria-label={`Avaliação: ${book.rating} de 5 estrelas`}>
                        <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" aria-hidden="true" />
                        <span className="text-sm">{book.rating}</span>
                      </div>
                    </div>

                    <div className="mb-2">
                      <Badge variant="outline" className="text-xs mb-1">
                        {book.edition}
                      </Badge>
                      <p className="text-xs text-muted-foreground">
                        {book.stock} {book.stock === 1 ? 'exemplar disponível' : 'exemplares disponíveis'}
                      </p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        {book.originalPrice && (
                          <span className="text-sm text-muted-foreground line-through mr-2">
                            R$ {book.originalPrice.toFixed(2)}
                          </span>
                        )}
                        <span className="font-semibold text-lg">R$ {book.price.toFixed(2)}</span>
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => onAddToCart(book.id)}
                        disabled={book.stock === 0}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {book.stock === 0 ? 'Esgotado' : 'Adicionar'}
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Melancholic Reading Corner */}
        <Card className="mt-8 relative overflow-hidden border-amber-700/40 bg-gradient-to-br from-amber-900/40 via-orange-900/30 to-slate-900/40">
          <div 
            className="absolute inset-0 opacity-25"
            style={{
              backgroundImage: `url(${dragonReadingImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
          <div className="relative z-10 p-6">
            <div className="text-center">
              <h3 className="font-semibold mb-3 text-amber-200">O Guardião dos Livros Raros</h3>
              <p className="text-sm text-amber-100/90 mb-4 italic leading-relaxed">
                "Cada edição limitada carrega consigo não apenas palavras, mas fragmentos de sonhos. 
                São tesouros que aguardam pacientemente por almas que compreendem o valor 
                da beleza preservada entre páginas que o tempo tornou preciosas."
              </p>
              <Button className="bg-amber-600/80 hover:bg-amber-700/90 text-amber-950 border border-amber-500/50">
                Descobrir Tesouros Raros
              </Button>
            </div>
          </div>
        </Card>

        {/* Club Membership CTA */}
        <Card className="mt-6 p-6 bg-gradient-to-r from-purple-900/30 to-indigo-900/30 border-purple-700/40">
          <div className="text-center">
            <Crown className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Clube de Colecionadores Drachen</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Acesso exclusivo a edições limitadas, descontos especiais e eventos VIP.
            </p>
            <Button className="bg-yellow-600 hover:bg-yellow-700 text-black">
              Tornar-se Membro
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}