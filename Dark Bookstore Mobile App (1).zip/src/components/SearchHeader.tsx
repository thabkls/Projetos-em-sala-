import { Search, Menu, ShoppingCart } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface SearchHeaderProps {
  cartCount?: number;
  onCartClick?: () => void;
  onMenuClick?: () => void;
}

export function SearchHeader({ cartCount = 0, onCartClick, onMenuClick }: SearchHeaderProps) {
  return (
    <header className="bg-card border-b border-border px-4 py-3 safe-area-inset-top">
      <div className="flex items-center gap-3">
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-foreground"
          onClick={onMenuClick}
          aria-label="Abrir menu de navegação"
        >
          <Menu className="w-5 h-5" />
        </Button>
        
        <div className="flex-1">
          <h1 className="text-lg font-semibold mb-2">🐉 Livraria Drachen</h1>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              placeholder="Buscar livros, autores..."
              className="pl-10 bg-secondary border-border text-foreground placeholder:text-muted-foreground"
              aria-label="Campo de busca para livros e autores"
            />
          </div>
        </div>
        
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-foreground relative"
          onClick={onCartClick}
          aria-label={`Carrinho de compras com ${cartCount} ${cartCount === 1 ? 'item' : 'itens'}`}
        >
          <ShoppingCart className="w-5 h-5" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </Button>
      </div>
    </header>
  );
}