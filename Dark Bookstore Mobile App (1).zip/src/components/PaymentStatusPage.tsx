import { CheckCircle, XCircle, Home, RotateCcw } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface PaymentStatusPageProps {
  success: boolean;
  onBackToHome: () => void;
  onTryAgain: () => void;
}

export function PaymentStatusPage({ success, onBackToHome, onTryAgain }: PaymentStatusPageProps) {
  if (success) {
    return (
      <div className="min-h-screen bg-background/95 dark:bg-background/98 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center">
          <div className="mb-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" aria-hidden="true" />
            </div>
            <h1 className="text-2xl font-semibold text-green-800 mb-2">Pagamento Aprovado!</h1>
            <p className="text-green-700">
              Sua compra foi realizada com sucesso. Você receberá um e-mail com os detalhes do pedido.
            </p>
          </div>

          <div className="space-y-3">
            <div className="bg-green-50 p-4 rounded-lg">
              <h2 className="font-semibold text-green-800 mb-2">Próximos Passos:</h2>
              <ul className="text-sm text-green-700 space-y-1 text-left">
                <li>• Confirmação enviada por e-mail</li>
                <li>• Prazo de entrega: 5-7 dias úteis</li>
                <li>• Acompanhe seu pedido no perfil</li>
              </ul>
            </div>

            <Button 
              onClick={onBackToHome}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              size="lg"
            >
              <Home className="w-4 h-4 mr-2" />
              Voltar à Loja
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background/95 dark:bg-background/98 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 text-center">
        <div className="mb-6">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <XCircle className="w-8 h-8 text-red-600" aria-hidden="true" />
          </div>
          <h1 className="text-2xl font-semibold text-red-800 mb-2">Pagamento Negado</h1>
          <p className="text-red-700">
            Houve um problema ao processar seu pagamento. Verifique os dados e tente novamente.
          </p>
        </div>

        <div className="space-y-3">
          <div className="bg-red-50 p-4 rounded-lg">
            <h2 className="font-semibold text-red-800 mb-2">Possíveis Causas:</h2>
            <ul className="text-sm text-red-700 space-y-1 text-left">
              <li>• Dados do cartão incorretos</li>
              <li>• Limite insuficiente</li>
              <li>• Cartão bloqueado ou vencido</li>
              <li>• Erro na operadora</li>
            </ul>
          </div>

          <div className="space-y-2">
            <Button 
              onClick={onTryAgain}
              className="w-full bg-red-600 hover:bg-red-700 text-white"
              size="lg"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Tentar Novamente
            </Button>

            <Button 
              onClick={onBackToHome}
              variant="outline"
              className="w-full border-red-200 text-red-700 hover:bg-red-50"
              size="lg"
            >
              <Home className="w-4 h-4 mr-2" />
              Voltar à Loja
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}