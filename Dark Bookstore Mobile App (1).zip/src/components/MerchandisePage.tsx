import { ArrowLeft, Heart, Star, Gift } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MerchandiseItem {
  id: string;
  name: string;
  price: number;
  rating: number;
  imageUrl: string;
  category: string;
  isNew: boolean;
  description: string;
}

interface MerchandisePageProps {
  onBack: () => void;
  onAddToCart: (id: string) => void;
}

const merchandiseItems: MerchandiseItem[] = [
  {
    id: 'merch1',
    name: 'Dados D20 Dragão Dourado',
    price: 45.90,
    rating: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1735720518793-804614ff5c48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwY29sbGVjdGlibGVzJTIwbWVyY2hhbmRpc2V8ZW58MXx8fHwxNzU3OTgxNzI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    category: 'Dados & Acessórios',
    isNew: true,
    description: 'Dados metálicos com detalhes dourados e gravações élficas'
  },
  {
    id: 'merch2',
    name: 'Mapa do Reino de Gondor',
    price: 89.90,
    rating: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1640688738996-4f3db1b7ad58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwbWFnaWMlMjBib29rcyUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzU3OTgxNzE3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    category: 'Decoração',
    isNew: false,
    description: 'Mapa artesanal em pergaminho envelhecido, 60x40cm'
  },
  {
    id: 'merch3',
    name: 'Caneca Taverna do Pônei Saltitante',
    price: 34.90,
    rating: 4.6,
    imageUrl: 'https://images.unsplash.com/photo-1677104165819-2e5ab9a0821f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwYm9va3MlMjBkdW5nZW9ucyUyMGRyYWdvbnN8ZW58MXx8fHwxNzU3OTgxNzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    category: 'Utensílios',
    isNew: false,
    description: 'Caneca em cerâmica com design medieval e frase élfica'
  },
  {
    id: 'merch4',
    name: 'Marcador de Página Espada Élfica',
    price: 19.90,
    rating: 4.7,
    imageUrl: 'https://images.unsplash.com/photo-1633081121114-f151f703832c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib2FyZCUyMGdhbWVzJTIwdGFibGV0b3AlMjBtZWRpZXZhbHxlbnwxfHx8fDE3NTc5ODE3MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    category: 'Acessórios',
    isNew: true,
    description: 'Marcador metálico com design de Sting, a espada de Bilbo'
  }
];

const categories = ['Todos', 'Dados & Acessórios', 'Decoração', 'Utensílios', 'Acessórios', 'Roupas'];

export function MerchandisePage({ onBack, onAddToCart }: MerchandisePageProps) {
  return (
    <div className="min-h-screen bg-background/95 dark:bg-background/98">
      <header className="bg-card border-b border-border px-4 py-3 safe-area-inset-top">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            aria-label="Voltar à página anterior"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Mimos & Colecionáveis</h1>
            <p className="text-sm text-muted-foreground">Itens especiais para apaixonados por fantasia</p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        {/* Hero Section */}
        <Card className="p-6 mb-6 bg-gradient-to-r from-emerald-900/20 to-teal-900/20 border-emerald-700/30">
          <div className="flex items-center gap-2 mb-2">
            <Gift className="w-5 h-5 text-emerald-500" />
            <h2 className="font-semibold">Tesouros Mágicos</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            De dados encantados a mapas místicos, encontre o presente perfeito para qualquer aventureiro.
          </p>
          <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
            <Heart className="w-3 h-3 mr-1" />
            Feito com amor artesanal
          </Badge>
        </Card>

        {/* Categories */}
        <section className="mb-6">
          <h2 className="mb-3">Categorias</h2>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant="outline"
                size="sm"
                className="whitespace-nowrap rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </section>

        {/* New Arrivals */}
        <section className="mb-8">
          <h2 className="mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            Novidades Encantadas
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {merchandiseItems.filter(item => item.isNew).map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-square relative">
                  <ImageWithFallback
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                  <Badge className="absolute top-2 left-2 bg-green-600 text-white text-xs">
                    Novo
                  </Badge>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm line-clamp-2 mb-1">{item.name}</h3>
                  <p className="text-xs text-muted-foreground mb-2">{item.category}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                      <span className="text-xs">{item.rating}</span>
                    </div>
                    <span className="font-semibold text-sm">R$ {item.price.toFixed(2)}</span>
                  </div>
                  <Button 
                    size="sm" 
                    className="w-full mt-2"
                    onClick={() => onAddToCart(item.id)}
                  >
                    Adicionar
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* All Items */}
        <section>
          <h2 className="mb-4">Todos os Mimos</h2>
          <div className="space-y-4">
            {merchandiseItems.map((item) => (
              <Card key={item.id} className="p-4 hover:shadow-lg transition-shadow">
                <div className="flex gap-4">
                  <div className="w-20 h-20 flex-shrink-0 relative">
                    <ImageWithFallback
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover rounded"
                    />
                    {item.isNew && (
                      <Badge className="absolute -top-2 -right-2 bg-green-600 text-white text-xs px-1 py-0.5">
                        Novo
                      </Badge>
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-medium line-clamp-1 mb-1">{item.name}</h3>
                        <p className="text-sm text-muted-foreground">{item.category}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                        <span className="text-sm">{item.rating}</span>
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {item.description}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-lg">R$ {item.price.toFixed(2)}</span>
                      <Button 
                        size="sm"
                        onClick={() => onAddToCart(item.id)}
                        className="bg-emerald-600 hover:bg-emerald-700"
                      >
                        Adicionar ao Carrinho
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Melancholic Collector's Corner */}
        <Card className="mt-8 p-6 bg-gradient-to-r from-slate-900/50 to-amber-900/40 border-slate-700/50">
          <div className="text-center">
            <h3 className="font-semibold mb-3 text-slate-200">O Colecionador Solitário</h3>
            <p className="text-sm text-slate-300/90 mb-4 italic leading-relaxed">
              "Cada item em nossa coleção carrega histórias silenciosas. São tesouros que aguardam 
              por mãos que saberão valorizar não apenas sua beleza, mas as memórias que eles ajudarão a criar."
            </p>
            <div className="flex justify-center gap-2 mb-4">
              <Badge variant="secondary" className="bg-amber-500/20 text-amber-300 border-amber-500/40">
                🕯️ Artesanal
              </Badge>
              <Badge variant="secondary" className="bg-slate-500/20 text-slate-300 border-slate-500/40">
                💭 Nostálgico
              </Badge>
            </div>
          </div>
        </Card>

        {/* Gift Card CTA */}
        <Card className="mt-6 p-6 bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-700/40">
          <div className="text-center">
            <Gift className="w-8 h-8 text-pink-500 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Vale-Presente Drachen</h3>
            <p className="text-sm text-muted-foreground mb-4">
              O presente perfeito para qualquer amante da fantasia. Válido em toda a loja.
            </p>
            <Button className="bg-pink-600 hover:bg-pink-700">
              Comprar Vale-Presente
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}