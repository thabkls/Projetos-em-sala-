import { Home, Book, Crown, Dice6, Calendar } from 'lucide-react';

interface NavItem {
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
  page: string;
}

const navItems: NavItem[] = [
  { icon: <Home className="w-5 h-5" />, label: 'Início', page: 'home' },
  { icon: <Book className="w-5 h-5" />, label: 'Coleções', page: 'collections' },
  { icon: <Crown className="w-5 h-5" />, label: 'Mimos', page: 'merchandise' },
  { icon: <Dice6 className="w-5 h-5" />, label: 'Jogos', page: 'games' },
  { icon: <Calendar className="w-5 h-5" />, label: 'Eventos', page: 'events' },
];

interface BottomNavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function BottomNavigation({ currentPage, onNavigate }: BottomNavigationProps) {
  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2 safe-area-inset-bottom"
      role="tablist"
      aria-label="Navegação principal"
    >
      <div className="flex items-center justify-around">
        {navItems.map((item) => (
          <button
            key={item.page}
            onClick={() => onNavigate(item.page)}
            className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors focus:ring-2 focus:ring-ring focus:ring-offset-2 ${
              currentPage === item.page 
                ? 'text-primary' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
            role="tab"
            aria-selected={currentPage === item.page}
            aria-label={`Navegar para ${item.label}`}
          >
            <span aria-hidden="true">{item.icon}</span>
            <span className="text-xs">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}