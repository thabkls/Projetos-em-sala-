interface SkipLinkProps {
  href: string;
  children: React.ReactNode;
}

export function SkipLink({ href, children }: SkipLinkProps) {
  return (
    <a
      href={href}
      className="absolute left-[-9999px] top-0 z-50 bg-primary text-primary-foreground px-4 py-2 rounded-br-lg focus:left-4 focus:top-4 transition-all duration-200"
      onFocus={(e) => {
        e.currentTarget.style.left = '1rem';
        e.currentTarget.style.top = '1rem';
      }}
      onBlur={(e) => {
        e.currentTarget.style.left = '-9999px';
        e.currentTarget.style.top = '0';
      }}
    >
      {children}
    </a>
  );
}