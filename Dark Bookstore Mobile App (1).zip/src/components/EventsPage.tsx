import { ArrowLeft, Calendar, MapPin, Users, Clock, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  price: number;
  maxParticipants: number;
  currentParticipants: number;
  category: string;
  description: string;
  isRecurring: boolean;
  difficulty: string;
}

interface EventsPageProps {
  onBack: () => void;
}

const events: Event[] = [
  {
    id: 'event1',
    title: 'Mesa de D&D: A Maldição de Strahd',
    date: '2025-01-20',
    time: '19:30',
    location: 'Loja Física - Sala dos Dragões',
    price: 25.00,
    maxParticipants: 6,
    currentParticipants: 4,
    category: 'RPG',
    description: 'Aventura épica no reino sombrio de Barovia. Campanha de longa duração para jogadores experientes.',
    isRecurring: true,
    difficulty: 'Avançado'
  },
  {
    id: 'event2',
    title: 'Clube do Livro: Tolkien Society',
    date: '2025-01-25',
    time: '15:00',
    location: 'Loja Física - Cantinho da Leitura',
    price: 0,
    maxParticipants: 12,
    currentParticipants: 8,
    category: 'Literatura',
    description: 'Discussão mensal sobre as obras de J.R.R. Tolkien. Este mês: O Silmarillion.',
    isRecurring: true,
    difficulty: 'Iniciante'
  },
  {
    id: 'event3',
    title: 'Torneio de Magic: The Gathering',
    date: '2025-01-28',
    time: '14:00',
    location: 'Loja Física - Arena Principal',
    price: 15.00,
    maxParticipants: 16,
    currentParticipants: 12,
    category: 'Card Game',
    description: 'Torneio formato Standard. Prêmios para os 3 primeiros colocados.',
    isRecurring: false,
    difficulty: 'Intermediário'
  },
  {
    id: 'event4',
    title: 'Noite de Jogos de Tabuleiro',
    date: '2025-02-01',
    time: '18:00',
    location: 'Loja Física - Salão Principal',
    price: 10.00,
    maxParticipants: 20,
    currentParticipants: 15,
    category: 'Board Games',
    description: 'Venha conhecer novos jogos e fazer novos amigos! Ambiente descontraído para toda família.',
    isRecurring: true,
    difficulty: 'Iniciante'
  },
  {
    id: 'event5',
    title: 'Workshop: Criando Personagens de D&D',
    date: '2025-02-05',
    time: '16:00',
    location: 'Loja Física - Sala de Workshops',
    price: 30.00,
    maxParticipants: 8,
    currentParticipants: 3,
    category: 'Workshop',
    description: 'Aprenda a criar personagens memoráveis para suas campanhas. Ideal para iniciantes.',
    isRecurring: false,
    difficulty: 'Iniciante'
  }
];

const categories = ['Todos', 'RPG', 'Literatura', 'Card Game', 'Board Games', 'Workshop'];

export function EventsPage({ onBack }: EventsPageProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: 'short',
      year: 'numeric'
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Iniciante': return 'bg-green-500/10 text-green-600 border-green-500/20';
      case 'Intermediário': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      case 'Avançado': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-gray-500/10 text-gray-600 border-gray-500/20';
    }
  };

  return (
    <div className="min-h-screen bg-background/95 dark:bg-background/98">
      <header className="bg-card border-b border-border px-4 py-3 safe-area-inset-top">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onBack}
            aria-label="Voltar à página anterior"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Eventos & Atividades</h1>
            <p className="text-sm text-muted-foreground">Participe da nossa comunidade presencial</p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6">
        {/* Hero Section */}
        <Card className="p-6 mb-6 bg-gradient-to-r from-indigo-900/20 to-purple-900/20 border-indigo-700/30">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-5 h-5 text-indigo-500" />
            <h2 className="font-semibold">Agenda Mágica</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Encontros, workshops e aventuras presenciais na nossa loja. A magia acontece quando nos reunimos!
          </p>
          <div className="flex gap-2">
            <Badge variant="secondary" className="bg-indigo-500/10 text-indigo-600 border-indigo-500/20">
              <MapPin className="w-3 h-3 mr-1" />
              Loja Física
            </Badge>
            <Badge variant="secondary" className="bg-purple-500/10 text-purple-600 border-purple-500/20">
              <Users className="w-3 h-3 mr-1" />
              Comunidade ativa
            </Badge>
          </div>
        </Card>

        {/* Categories */}
        <section className="mb-6">
          <h2 className="mb-3">Categorias</h2>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant="outline"
                size="sm"
                className="whitespace-nowrap rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="mb-8">
          <h2 className="mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            Próximos Eventos
          </h2>
          <div className="space-y-4">
            {events.map((event) => {
              const isAlmostFull = event.currentParticipants >= event.maxParticipants * 0.8;
              const isFull = event.currentParticipants >= event.maxParticipants;
              
              return (
                <Card key={event.id} className="p-4 hover:shadow-lg transition-shadow">
                  <div className="flex flex-col gap-4">
                    {/* Event Header */}
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-medium">{event.title}</h3>
                          {event.isRecurring && (
                            <Badge variant="outline" className="text-xs">
                              Recorrente
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {formatDate(event.date)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {event.time}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                          <MapPin className="w-4 h-4" />
                          {event.location}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-lg">
                          {event.price === 0 ? 'Gratuito' : `R$ ${event.price.toFixed(2)}`}
                        </p>
                      </div>
                    </div>

                    {/* Event Details */}
                    <div>
                      <p className="text-sm text-muted-foreground mb-3">
                        {event.description}
                      </p>
                      
                      <div className="flex items-center gap-2 mb-4">
                        <Badge variant="outline" className="text-xs">
                          {event.category}
                        </Badge>
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getDifficultyColor(event.difficulty)}`}
                        >
                          {event.difficulty}
                        </Badge>
                      </div>

                      {/* Participants and Action */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {event.currentParticipants}/{event.maxParticipants} participantes
                          </span>
                          {isAlmostFull && !isFull && (
                            <Badge className="bg-yellow-600/20 text-yellow-600 text-xs">
                              Quase lotado
                            </Badge>
                          )}
                          {isFull && (
                            <Badge className="bg-red-600/20 text-red-600 text-xs">
                              Lotado
                            </Badge>
                          )}
                        </div>
                        
                        <Button 
                          size="sm"
                          disabled={isFull}
                          className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
                        >
                          {isFull ? 'Lotado' : 'Inscrever-se'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Atmospheric Events Section */}
        <Card className="mb-6 p-6 bg-gradient-to-r from-slate-900/50 to-purple-900/40 border-slate-700/50">
          <div className="text-center">
            <h3 className="font-semibold mb-3 text-slate-200">Onde Histórias Ganham Vida</h3>
            <p className="text-sm text-slate-300/90 mb-4 italic leading-relaxed">
              "Em nossa loja, o tempo parece correr mais devagar. Aqui, entre estantes antigas 
              e a luz suave das lâmpadas, cada evento é uma oportunidade de criar memórias 
              que permanecerão conosco muito depois que as últimas páginas forem viradas."
            </p>
          </div>
        </Card>

        {/* Location Info */}
        <Card className="p-6 bg-gradient-to-r from-green-900/20 to-emerald-900/20 border-green-700/30">
          <div className="text-center">
            <MapPin className="w-8 h-8 text-emerald-500 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Visite Nossa Loja</h3>
            <p className="text-sm text-muted-foreground mb-2">
              Rua dos Magos, 123 - Centro Fantástico
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              Seg-Sex: 10h-22h | Sáb-Dom: 9h-20h
            </p>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              Ver no Mapa
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}