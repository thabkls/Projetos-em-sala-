import { ImageWithFallback } from './figma/ImageWithFallback';
import { Star, ShoppingCart } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface BookCardProps {
  id: string;
  title: string;
  author: string;
  price: string;
  rating: number;
  coverUrl: string;
  isHorizontal?: boolean;
  onAddToCart?: (id: string) => void;
}

export function BookCard({ id, title, author, price, rating, coverUrl, isHorizontal = false, onAddToCart }: BookCardProps) {
  if (isHorizontal) {
    return (
      <Card className="flex bg-card border-border overflow-hidden focus-within:ring-2 focus-within:ring-ring">
        <div className="w-20 h-24 flex-shrink-0">
          <ImageWithFallback
            src={coverUrl}
            alt={`Capa do livro ${title}`}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 p-3 flex flex-col justify-between">
          <div>
            <h4 className="text-sm line-clamp-2 mb-1">{title}</h4>
            <p className="text-xs text-muted-foreground mb-2">por {author}</p>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1" role="img" aria-label={`Avaliação: ${rating} de 5 estrelas`}>
              <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" aria-hidden="true" />
              <span className="text-xs">{rating}</span>
            </div>
            <span className="text-sm font-medium text-primary" aria-label={`Preço: ${price}`}>{price}</span>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border overflow-hidden focus-within:ring-2 focus-within:ring-ring">
      <div className="aspect-[3/4] w-full">
        <ImageWithFallback
          src={coverUrl}
          alt={`Capa do livro ${title}`}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-3">
        <h4 className="text-sm line-clamp-2 mb-1">{title}</h4>
        <p className="text-xs text-muted-foreground mb-2">por {author}</p>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1" role="img" aria-label={`Avaliação: ${rating} de 5 estrelas`}>
            <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" aria-hidden="true" />
            <span className="text-xs">{rating}</span>
          </div>
          <span className="text-sm font-medium text-primary" aria-label={`Preço: ${price}`}>{price}</span>
        </div>
        <Button 
          size="sm" 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground focus:ring-2 focus:ring-ring focus:ring-offset-2"
          onClick={() => onAddToCart?.(id)}
          aria-label={`Adicionar ${title} ao carrinho`}
        >
          <ShoppingCart className="w-3 h-3 mr-1" aria-hidden="true" />
          Adicionar
        </Button>
      </div>
    </Card>
  );
}