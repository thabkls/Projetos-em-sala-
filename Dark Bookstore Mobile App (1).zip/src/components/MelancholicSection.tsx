import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { BookOpen, Heart, Moon, Flame } from 'lucide-react';
import dragonBookImage from 'figma:asset/8442087deef48f76643da4b5019e5c52ec110ff3.png';
import dragonReadingImage from 'figma:asset/aacf175f583e6596e90950db2cf4fbf11d158dc1.png';

interface MelancholicSectionProps {
  onNavigate?: (page: string) => void;
}

export function MelancholicSection({ onNavigate }: MelancholicSectionProps) {
  const melancholicQuotes = [
    {
      text: "Na quietude da leitura, encontramos companhia para nossa solidão mais profunda.",
      author: "Sussurro do Dragão Ancestral",
      image: dragonReadingImage,
      theme: "from-slate-900/60 via-blue-900/40 to-indigo-900/30"
    },
    {
      text: "Cada página virada é uma despedida silenciosa, cada história terminada, uma pequena morte.",
      author: "Lamento dos Pergaminhos",
      image: dragonBookImage,
      theme: "from-amber-900/50 via-orange-900/40 to-red-900/30"
    }
  ];

  return (
    <section className="px-4 pb-8">
      <h2 className="mb-6 flex items-center gap-2 text-center justify-center">
        <Moon className="w-5 h-5 text-slate-400" />
        <span className="text-slate-300">Reflexões Melancólicas</span>
        <Moon className="w-5 h-5 text-slate-400" />
      </h2>
      
      <div className="space-y-6">
        {melancholicQuotes.map((quote, index) => (
          <Card 
            key={index}
            className={`relative overflow-hidden border-slate-700/50 bg-gradient-to-br ${quote.theme}`}
          >
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: `url(${quote.image})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            />
            <div className="relative z-10 p-6">
              <div className="text-center">
                <blockquote className="text-slate-200/95 mb-4 leading-relaxed italic text-lg">
                  "{quote.text}"
                </blockquote>
                <cite className="text-slate-400 text-sm">
                  — {quote.author}
                </cite>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Atmospheric Reading Corner */}
      <Card className="mt-8 relative overflow-hidden border-amber-700/30 bg-gradient-to-br from-amber-900/30 via-slate-900/40 to-purple-900/20">
        <div className="relative z-10 p-8">
          <div className="text-center">
            <div className="flex justify-center items-center gap-2 mb-4">
              <Flame className="w-6 h-6 text-amber-400" />
              <h3 className="font-semibold text-amber-200">Cantinho das Lembranças</h3>
              <Flame className="w-6 h-6 text-amber-400" />
            </div>
            
            <p className="text-amber-100/90 mb-6 leading-relaxed italic max-w-md mx-auto">
              "Venha descobrir livros que despertam saudades de lugares que nunca visitamos 
              e de pessoas que existem apenas em nossos sonhos mais profundos."
            </p>
            
            <div className="flex justify-center gap-3 mb-6">
              <Badge variant="secondary" className="bg-amber-500/20 text-amber-300 border-amber-500/40">
                <Heart className="w-3 h-3 mr-1" />
                Nostalgia
              </Badge>
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/40">
                <BookOpen className="w-3 h-3 mr-1" />
                Melancolia
              </Badge>
              <Badge variant="secondary" className="bg-slate-500/20 text-slate-300 border-slate-500/40">
                <Moon className="w-3 h-3 mr-1" />
                Contemplação
              </Badge>
            </div>
            
            <Button 
              className="bg-amber-600/70 hover:bg-amber-700/80 text-amber-950 border border-amber-500/50"
              onClick={() => onNavigate && onNavigate('collections')}
            >
              Explorar Tesouros Melancólicos
            </Button>
          </div>
        </div>
      </Card>
    </section>
  );
}