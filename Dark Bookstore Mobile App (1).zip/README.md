
  # Dark Bookstore Mobile App

  This is a code bundle for Dark Bookstore Mobile App. The original project is available at https://www.figma.com/design/0psOJpr1Ie4ydw47bOBAiQ/Dark-Bookstore-Mobile-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  